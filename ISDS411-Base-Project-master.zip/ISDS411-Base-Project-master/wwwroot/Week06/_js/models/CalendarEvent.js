﻿

// A model of a calendar event to be used in mustache templates
export class CalendarEvent {

    constructor(settings) {

        // Spit back the object if the input is the same type
        // Useful trick for better VS Code intellisense
        if (settings instanceof CalendarEvent) return settings;

        // Establish Default Values for Custom Properties

        this.summary = "Blank Event";
        this.description = "Blank Event Description";
        this.date = new Date();


        // Use settings object to inject any custom property values desired
        Object.assign(this, settings);
    }

    // Calculate the human-readable string for the date on the fly
    get time() {
        return this.date.toISOString();
    }
}
