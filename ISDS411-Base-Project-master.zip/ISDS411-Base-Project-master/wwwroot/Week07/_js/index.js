﻿import { App } from '../_js/app/app.js';

const app = new App({
    owner: `Steven Cooper`
});


const ApiUrl = "https://www.googleapis.com/calendar/v3/calendars/27525cc8366c434e17fcf5e8b3d84e73a2fb652e09721497179a1dff40413e32@group.calendar.google.com/events";

let query = "?key=AIzaSyAUYlHta_5W4E6JdtqI8D-xRrJ1TE6DTRw&singleEvents=true&orderBy=startTime&timeMin=2024-09-01T07:00:00.000Z&timeMax=2024-9-30T10:00:00-07:00";

let targetUrl = `${ApiUrl}${query}`;

app.loadCalendar({
    url: targetUrl,
    selector: "#MyCalendar"
});

(async () => {

    await app.getCalendar(targetUrl);

    await app.renderCalendar("#MyCalendar");

})();
