﻿
// A model of a calendar event to be used in mustache templates
export class CalendarEvent {

    constructor(settings) {

        // Spit back the object if the input is the same type
        // Useful trick for better VS Code intellisense
        if (settings instanceof CalendarEvent) return settings;

        // Establish Default Values for Custom Properties

        this.summary = "Blank Event";
        this.description = "Blank Event Description";
        this.location = "Somewhere Happy";
        this.start = {};
        this.end = {};

        settings = settings || {}; // Default settings to a blank object

        // Use settings object to inject any custom property values desired
        Object.assign(this, settings);

        // If the "start" object has a "date" property, there is no time
        // and the event is an "All Day" event. Timed events have a dateTime
        // property instead. 
        this.allDay = this.start.date ? true : false;



        if (this.start.date) {
            this.start.date = `${this.start.date} PST`; // Put the date in our local time zone
        }
    }

    // Events can be "All Day" or specific times
    // Events can be 1 date or a date range
    // We need a lot of supplemental functions to convert 
    // everything into a single date for sorting and displaying

    get timeStart() {
        if (this.start.dateTime) {
            let dt = new Date(this.start.dateTime);
            let time = dt.toLocaleTimeString("en-US", { timeStyle: "short" });

            return `${time}`;
        }
        return false;
    }

    get timeEnd() {
        if (this.end.dateTime) {
            let dt = new Date(this.end.dateTime);
            let time = dt.toLocaleTimeString("en-US", { timeStyle: "short" });
            return `${time}`;
        }
        return false;
    }

    timeDate(type) {

        let dt = this[type]?.dateTime;

        this.start.dateTime;

        if (dt) {
            let date = new Date(dt);
            return date.toLocaleDateString();
        }
        return false;
    }

    // Gets the start date, needed because it could be "date" or "dateTime"
    dateStart() {
        let date = this.start.date ?? this.start.dateTime;
        let dt = new Date(date);
        return dt;
    }

    // Month of the start date
    get startMonth() {
        return this.dateStart().toLocaleString('en-us', { month: 'short' });
    }

    // Day of the start date
    get startDay() {
        return this.dateStart().toLocaleString('en-us', { day: '2-digit' });
    }

    // A sortable date object
    get sortDate() {
        return new Date(this.start.date ?? this.start.dateTime);
    }

    // Returns the date of the event in a string we can display
    get eventDate() {

        let dateString = "No Date Available",
            sDate = "01/01/2001",
            eDate = "01/01/2001";

        if (this.allDay) {

            sDate = new Date(this.start.date);
            eDate = new Date(this.end.date);

            // If the dates are essentially the same, just use 1 and say "All Day"
            if (eDate.getUTCDay() - sDate.getUTCDay() < 2) {
                dateString = `${sDate.toLocaleDateString()} (All Day)`;
            } else {
                // The dates are different, we'll print out each date *and* time
                dateString = `${sDate.toLocaleDateString()} - ${eDate.toLocaleDateString()}`;
            }
        }
        else {

            sDate = this.timeDate("start");
            eDate = this.timeDate("end");

            if (sDate != eDate) {
                dateString = `${sDate} (${this.timeStart}) - ${eDate} (${this.timeEnd})`;
            }
            else {
                dateString = `${sDate} (${this.timeStart} - ${this.timeEnd})`;
            }
        }

        return dateString;
    }
}