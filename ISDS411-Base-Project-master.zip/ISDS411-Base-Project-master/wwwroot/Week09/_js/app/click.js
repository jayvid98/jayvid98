﻿
const clickActions = {};

clickActions.doStuff = () => {
    alert("Thank you for clicking");
};

clickActions.sayBye = function () {
    alert("PARTING IS SUCH SWEET SORROW!");
}

document.addEventListener("click", (e) => {

    let src = e.target;

    let actionName = src.dataset.click;

    if (!actionName) {
        let parent = src.closest("[data-click]");

        actionName = parent?.dataset.click;
    }

    clickActions[actionName]?.(e);
});