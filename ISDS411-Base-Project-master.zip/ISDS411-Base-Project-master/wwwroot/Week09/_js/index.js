﻿import { App } from '../_js/app/app.js';

const app = new App({
    owner: `Steven Cooper`
});

const calId = `213f3d889e1f7b3707950f4dedf02c6614f283edb34d527a0639caf43a229bdd@group.calendar.google.com`;

const ApiKey = `AIzaSyAUYlHta_5W4E6JdtqI8D-xRrJ1TE6DTRw`;

const ApiUrl = `https://www.googleapis.com/calendar/v3/calendars/${calId}/events`;

let query = `?key=${ApiKey}&singleEvents=true&orderBy=startTime`;

// &timeMin=2024-09-01T07:00:00.000Z&timeMax=2024-9-30T10:00:00-07:00

let targetUrl = `${ApiUrl}${query}`;

app.loadCalendar({
    url: targetUrl,
    selector: "#MyCalendar"
});

(async () => {

    await app.getCalendar(targetUrl);

    await app.renderCalendar("#MyCalendar");

})();
