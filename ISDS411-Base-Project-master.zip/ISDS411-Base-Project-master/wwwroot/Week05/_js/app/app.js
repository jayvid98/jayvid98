﻿export class App {

    constructor(app) {

        if (app instanceof App) return app;

        window.app = window.app ?? this;

        this.version = 1;

        this.year = new Date().getFullYear();

    }

    get fancyVersion() {

        return `${this.version}!!!!!!!!`;
    }

    updateTitle(selector) {

        let source = document.querySelector(selector) ?? false;

        if (!source) {
            console.log(`Target Element "${selector}" not found.`);
            return false;
        }

        let text = source.innerHTML;

        let heading = document.querySelector("h1");

        if (heading) {
            heading.innerHTML = text;
        }
    }

}