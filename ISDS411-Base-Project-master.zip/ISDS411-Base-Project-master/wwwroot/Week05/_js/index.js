﻿import { App } from '../_js/app/app.js';

doStuff();

const app = new App();

console.log(`You are using app.js version ${app.fancyVersion}`);

app.updateTitle("title");

let footerTemplate = `&copy; ${app.year} Steven Cooper, All Rights Reserved.`;

let copyInfo = document.querySelector("#CopyrightInfo");

if (copyInfo) {
    copyInfo.innerHTML = footerTemplate;
}


async function doStuff() {

    let request = await fetch("https://www.googleapis.com/calendar/v3/calendars/27525cc8366c434e17fcf5e8b3d84e73a2fb652e09721497179a1dff40413e32@group.calendar.google.com/events?key=AIzaSyAUYlHta_5W4E6JdtqI8D-xRrJ1TE6DTRw&singleEvents=true&orderBy=startTime&timeMin=2024-09-01T07:00:00.000Z&timeMax=2024-9-30T10:00:00-07:00");

    let response = await request.json();

    response.items.forEach((event) => {

        const template = `<li> Event Summary: ${event.summary}</li>`;

        let list = document.querySelector("#DemoList");

        if (list) {

            list.insertAdjacentHTML("beforeend", template);

        }

    });

    console.log(response);

}

