﻿
const clickActions = {};

clickActions.doStuff = () => {
    alert("Thank you for clicking");
};

clickActions.sayBye = function () {
    alert("PARTING IS SUCH SWEET SORROW!");
}

const nums = [
    {
        title: "My Birthday",
        date: new Date("2024-10-28")
    },
    {
        title: "Bob's Birthday",
        date: new Date("2024-05-28")
    },
    {
        title: "Juan's Birthday",
        date: new Date("2024-02-03")
    },
    {
        title: "Tina's Birthday",
        date: new Date("2024-12-25")
    }
];

clickActions.sortData = () => {

    let inputData = nums;

    inputData.sort((a, b) => a.date - b.date);

    inputData.forEach((item) => {
        console.log(`Event: ${item.title}, Date: ${item.date.toLocaleDateString()}`);
    });

};

document.addEventListener("click", (e) => {

    let src = e.target;

    let actionName = src.dataset.click;

    if (!actionName) {
        let parent = src.closest("[data-click]");

        actionName = parent?.dataset.click;
    }

    clickActions[actionName]?.(e);
});