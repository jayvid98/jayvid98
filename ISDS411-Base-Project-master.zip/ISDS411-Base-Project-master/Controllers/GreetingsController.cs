﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace ISDS411_Base_Project.Controllers
{
    public class Greeting
    {
        public string Message { get; set; }
        public string? Sender { get; set; }
        public bool sent { get; set; }

        public Greeting(string message, string? sender = "NO Sender")
        {
            this.Message = message;
            this.Sender = sender;
            this.sent = false;
        }
    }

    [ApiController]
    [Route("api/[controller]")]
    public class GreetingsController : ControllerBase
    {
        [HttpGet]
        public IActionResult Get()
        {
            ContentResult result = new ContentResult()
            {
                StatusCode = 200,
                ContentType = "text/html"
            };

            result.Content = "<h1>Wazzup!</h1>";

            return result;
        }

      

        [HttpPost]
        public Greeting Post(Greeting greeting)
        {
            Greeting result = new(greeting.Message, greeting.Sender)
            {
                sent = true
            };

            return result;
        }


        [Route("Events/{title}")]
        [HttpGet]
        public IActionResult Get(string title)
        {
            ContentResult result = new ContentResult()
            {
                StatusCode = 200,
                ContentType = "text/html"
            };


            result.Content = "Your Event title is " + title;

            return result;
        }

        [Route("Weird/{word?}")]
        [HttpGet]
        public IActionResult GetWeird(string? word)
        {
            try
            {
                ContentResult result = new ContentResult()
                {
                    StatusCode = 200,
                    ContentType = "text/html"
                };

                result.Content = "<h1>Let's Get Weird Up In Here!</h1>";
                result.Content += "<strong>The Word Is: " + word + "</strong>";

                return result;
            }
            catch (Exception ex)
            {
                return ContentError(ex);
            }
        }

        private ContentResult ContentError(Exception ex)
        {
            return new ContentResult()
            {
                StatusCode = 500,
                ContentType = "text/html",
                Content = ex.Message
            };
        }

    }
}
