﻿namespace ISDS411_Base_Project.Helpers
{
    public class Data
    {
        public string YourVar { get; set; } 
        private string? _name;

        public string Name {
            get { 
                return _name; 
            }
            set {
                _name = value;
            }
        }

        private string? description { get; set; }

        public Data()
        {
            this.Name = "DefaultName";
        }
        public Data(string p_name) {

            string MyVar = p_name;

            YourVar = p_name;


        }

        public Data(string p_name, string p_description)
        {



            this.Name = p_name;
            this.description = p_description;
        }

        public void bob()
        {
            
        }


    }
}
